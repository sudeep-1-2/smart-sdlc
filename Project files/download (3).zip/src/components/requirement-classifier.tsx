"use client";

import { useState } from "react";
import {
  FileText,
  Loader2,
  LayoutTemplate,
  Code,
  TestTube,
  Rocket,
  Folder,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useToast } from "@/hooks/use-toast";
import { classifyRequirements, type ClassifyRequirementsOutput } from "@/ai/flows/classify-requirements";

type GroupedRequirements = {
  [key: string]: string[];
};

const phaseIcons: { [key: string]: React.ReactNode } = {
  Requirements: <FileText className="h-5 w-5 text-sky-500" />,
  Design: <LayoutTemplate className="h-5 w-5 text-purple-500" />,
  Development: <Code className="h-5 w-5 text-green-500" />,
  Testing: <TestTube className="h-5 w-5 text-yellow-500" />,
  Deployment: <Rocket className="h-5 w-5 text-red-500" />,
  Other: <Folder className="h-5 w-5 text-gray-500" />,
};

const phaseOrder = ['Requirements', 'Design', 'Development', 'Testing', 'Deployment', 'Other'];

export default function RequirementClassifier() {
  const [text, setText] = useState("");
  const [groupedResults, setGroupedResults] = useState<GroupedRequirements | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) {
      toast({
        title: "Error",
        description: "Please enter some text to classify.",
        variant: "destructive",
      });
      return;
    }
    setIsLoading(true);
    setGroupedResults(null);
    try {
      const results: ClassifyRequirementsOutput = await classifyRequirements({ documentText: text });
      
      const grouped = results.reduce((acc: GroupedRequirements, item) => {
        const phase = item.phase || "Other";
        if (!acc[phase]) {
          acc[phase] = [];
        }
        acc[phase].push(item.requirement);
        return acc;
      }, {});

      setGroupedResults(grouped);
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "Failed to classify requirements. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>AI Requirement Classifier</CardTitle>
          <CardDescription>
            Paste unstructured requirements, and our AI will classify each sentence into specific SDLC phases.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid gap-2">
              <label htmlFor="requirement-input" className="font-medium">
                Your Requirements
              </label>
              <Textarea
                id="requirement-input"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Paste your unstructured text from documents here..."
                className="min-h-[200px]"
              />
            </div>
            <Button type="submit" disabled={isLoading} className="w-full sm:w-auto">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Classifying...
                </>
              ) : (
                <>
                  <FileText className="mr-2 h-4 w-4" />
                  Classify Requirements
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {groupedResults && (
        <Card>
          <CardHeader>
            <CardTitle>Classified Requirements</CardTitle>
            <CardDescription>
              Your requirements have been organized into the following SDLC phases.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="multiple" className="w-full" defaultValue={phaseOrder}>
              {phaseOrder.map((phase) =>
                groupedResults[phase] ? (
                  <AccordionItem value={phase} key={phase}>
                    <AccordionTrigger className="text-lg font-medium hover:no-underline">
                      <div className="flex items-center gap-3">
                        {phaseIcons[phase]}
                        <span>{phase}</span>
                        <span className="text-sm font-normal bg-muted text-muted-foreground rounded-full px-2 py-0.5">
                          {groupedResults[phase].length}
                        </span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <ul className="space-y-3 pl-6">
                        {groupedResults[phase].map((req, index) => (
                          <li key={index} className="flex items-start gap-3">
                            <ChevronRight className="h-5 w-5 mt-0.5 text-muted-foreground flex-shrink-0" />
                            <span className="text-foreground/80">{req}</span>
                          </li>
                        ))}
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                ) : null
              )}
            </Accordion>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
