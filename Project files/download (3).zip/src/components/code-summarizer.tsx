"use client";

import { useState } from "react";
import { BookText, Bot, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { summarizeCode } from "@/ai/flows/summarize-code";

export default function CodeSummarizer() {
  const [code, setCode] = useState("");
  const [summary, setSummary] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) {
      toast({
        title: "Error",
        description: "Please enter some code to summarize.",
        variant: "destructive",
      });
      return;
    }
    setIsLoading(true);
    setSummary("");
    try {
      const result = await summarizeCode({ code });
      setSummary(result.summary);
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "Failed to summarize code. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>AI Code Summarizer</CardTitle>
          <CardDescription>
            Paste any source code snippet, and our AI will generate a human-readable explanation of its logic and purpose.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid gap-2">
              <label htmlFor="code-input" className="font-medium">
                Code Snippet
              </label>
              <Textarea
                id="code-input"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Paste any source code snippet here..."
                className="min-h-[200px] font-mono text-sm"
              />
            </div>
            <Button type="submit" disabled={isLoading} className="w-full sm:w-auto">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Summarizing...
                </>
              ) : (
                <>
                  <BookText className="mr-2 h-4 w-4" />
                  Summarize Code
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {summary && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bot /> AI Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose prose-sm dark:prose-invert max-w-none text-foreground/80">
              {summary}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
