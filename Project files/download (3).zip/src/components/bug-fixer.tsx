"use client";

import { useState } from "react";
import { Bot, Bug, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { fixCodeBugs, type FixCodeBugsOutput } from "@/ai/flows/fix-code-bugs";
import CodeBlock from "./code-block";

export default function BugFixer() {
  const [code, setCode] = useState("");
  const [language, setLanguage] = useState("javascript");
  const [result, setResult] = useState<FixCodeBugsOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) {
      toast({
        title: "Error",
        description: "Please enter some code to fix.",
        variant: "destructive",
      });
      return;
    }
    setIsLoading(true);
    setResult(null);
    try {
      const fixed = await fixCodeBugs({ code, language });
      setResult(fixed);
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "Failed to fix code. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>AI Bug Fixer</CardTitle>
          <CardDescription>
            Submit your buggy code, and our AI will analyze it to fix both syntactical and logical errors.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid gap-2">
              <label htmlFor="code-input" className="font-medium">
                Your Code
              </label>
              <Textarea
                id="code-input"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Paste your buggy Python or JavaScript code here..."
                className="min-h-[200px] font-mono text-sm"
              />
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                 <label htmlFor="language-select" className="font-medium text-sm">
                    Language
                  </label>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger id="language-select">
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="javascript">JavaScript</SelectItem>
                    <SelectItem value="python">Python</SelectItem>
                    <SelectItem value="typescript">TypeScript</SelectItem>
                    <SelectItem value="go">Go</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" disabled={isLoading} className="w-full sm:w-auto self-end">
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Fixing...
                  </>
                ) : (
                  <>
                    <Bug className="mr-2 h-4 w-4" />
                    Fix Code
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {result && (
        <div className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Original Code</CardTitle>
              </CardHeader>
              <CardContent>
                <CodeBlock code={code} language={language} />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Corrected Code</CardTitle>
              </CardHeader>
              <CardContent>
                <CodeBlock code={result.optimizedCode} language={language} />
              </CardContent>
            </Card>
          </div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bot /> AI Explanation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm dark:prose-invert max-w-none text-foreground/80">
                {result.explanation}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
