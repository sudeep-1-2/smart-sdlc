import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BookText, Bug, FileText, Wand2 } from "lucide-react";

export default function Dashboard() {
  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold tracking-tight">Welcome to SmartSDLC</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Your AI-Enhanced Software Development Lifecycle Assistant
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Getting Started</CardTitle>
          <CardDescription>
            Select a tool from the sidebar to begin automating your development workflow.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <FeatureCard
              icon={<FileText className="w-8 h-8 text-primary" />}
              title="Requirement Classifier"
              description="Upload requirements to automatically classify them into SDLC phases."
            />
            <FeatureCard
              icon={<Wand2 className="w-8 h-8 text-primary" />}
              title="AI Code Generator"
              description="Generate code snippets from plain English descriptions in seconds."
            />
            <FeatureCard
              icon={<Bug className="w-8 h-8 text-primary" />}
              title="Bug Fixer"
              description="Find and fix bugs in your code with intelligent AI analysis."
            />
            <FeatureCard
              icon={<BookText className="w-8 h-8 text-primary" />}
              title="Code Summarizer"
              description="Get easy-to-understand summaries of complex code for documentation."
            />
          </div>
        </CardContent>
      </Card>
       <div data-ai-hint="abstract technology" className="w-full h-64 rounded-lg bg-gray-200 dark:bg-gray-800 flex items-center justify-center">
         <p className="text-muted-foreground">Imagine a world-class abstract image here.</p>
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="flex flex-col items-center p-6 text-center bg-background rounded-lg border shadow-sm">
      <div className="mb-4">{icon}</div>
      <h3 className="mb-2 text-lg font-semibold">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  )
}
