import { config } from 'dotenv';
config();

import '@/ai/flows/generate-code-from-prompt.ts';
import '@/ai/flows/classify-requirements.ts';
import '@/ai/flows/summarize-code.ts';
import '@/ai/flows/fix-code-bugs.ts';