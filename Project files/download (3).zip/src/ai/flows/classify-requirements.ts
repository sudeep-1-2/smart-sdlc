'use server';

/**
 * @fileOverview Classifies software requirements into SDLC phases.
 *
 * - classifyRequirements - A function that classifies requirements.
 * - ClassifyRequirementsInput - The input type for the classifyRequirements function.
 * - ClassifyRequirementsOutput - The return type for the classifyRequirements function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ClassifyRequirementsInputSchema = z.object({
  documentText: z
    .string()
    .describe('The text content of the document containing software requirements.'),
});
export type ClassifyRequirementsInput = z.infer<typeof ClassifyRequirementsInputSchema>;

const SDLCPhaseSchema = z.enum([
  'Requirements',
  'Design',
  'Development',
  'Testing',
  'Deployment',
  'Other',
]);

const ClassifiedRequirementSchema = z.object({
  requirement: z.string().describe('The individual requirement text.'),
  phase: SDLCPhaseSchema.describe('The SDLC phase the requirement belongs to.'),
});

const ClassifyRequirementsOutputSchema = z.array(ClassifiedRequirementSchema);
export type ClassifyRequirementsOutput = z.infer<typeof ClassifyRequirementsOutputSchema>;

export async function classifyRequirements(
  input: ClassifyRequirementsInput
): Promise<ClassifyRequirementsOutput> {
  return classifyRequirementsFlow(input);
}

const classifyRequirementsPrompt = ai.definePrompt({
  name: 'classifyRequirementsPrompt',
  input: {schema: ClassifyRequirementsInputSchema},
  output: {schema: ClassifyRequirementsOutputSchema},
  prompt: `You are an expert software project manager.

You will be provided with a document containing software requirements. Your task is to classify each requirement into one of the following SDLC phases: Requirements, Design, Development, Testing, or Deployment. If a requirement doesn't fit into any of these phases, classify it as 'Other'.

For each requirement, provide the requirement text and the SDLC phase it belongs to.

Document:
{{{documentText}}}

Output in JSON format an array of objects, where each object has the requirement and the phase:

Example:
[
  {
    "requirement": "The system should allow users to log in with their credentials.",
    "phase": "Requirements"
  },
  {
    "requirement": "Create a database schema for storing user data.",
    "phase": "Design"
  }
]

Ensure that the output is a valid JSON array of objects, and each object contains the requirement and its corresponding SDLC phase.
`,
});

const classifyRequirementsFlow = ai.defineFlow(
  {
    name: 'classifyRequirementsFlow',
    inputSchema: ClassifyRequirementsInputSchema,
    outputSchema: ClassifyRequirementsOutputSchema,
  },
  async input => {
    const {output} = await classifyRequirementsPrompt(input);
    return output!;
  }
);
