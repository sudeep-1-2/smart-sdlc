'use server';

/**
 * @fileOverview AI agent to analyze and fix code snippets for syntactical and logical errors.
 *
 * - fixCodeBugs - A function that accepts code and returns an optimized version.
 * - FixCodeBugsInput - The input type for the fixCodeBugs function.
 * - FixCodeBugsOutput - The return type for the fixCodeBugs function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const FixCodeBugsInputSchema = z.object({
  code: z
    .string()
    .describe('The code snippet to analyze and fix, supporting languages like Python or JavaScript.'),
  language: z
    .string()
    .describe('The programming language of the code snippet.'),
});

export type FixCodeBugsInput = z.infer<typeof FixCodeBugsInputSchema>;

const FixCodeBugsOutputSchema = z.object({
  optimizedCode: z
    .string()
    .describe('The optimized version of the code snippet with syntactical and logical errors fixed.'),
  explanation: z
    .string()
    .describe('Explanation of the changes made to the code and the errors that were fixed.'),
});

export type FixCodeBugsOutput = z.infer<typeof FixCodeBugsOutputSchema>;

export async function fixCodeBugs(input: FixCodeBugsInput): Promise<FixCodeBugsOutput> {
  return fixCodeBugsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'fixCodeBugsPrompt',
  input: {schema: FixCodeBugsInputSchema},
  output: {schema: FixCodeBugsOutputSchema},
  prompt: `You are an AI expert in debugging code.

You will receive a code snippet and your task is to identify and fix any syntactical and logical errors.
Return the optimized code along with an explanation of the changes you made and the errors that were fixed.

Language: {{{language}}}
Code: {{{code}}}`,
});

const fixCodeBugsFlow = ai.defineFlow(
  {
    name: 'fixCodeBugsFlow',
    inputSchema: FixCodeBugsInputSchema,
    outputSchema: FixCodeBugsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
