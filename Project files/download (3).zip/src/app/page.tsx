"use client";

import * as React from "react";
import {
  BookText,
  Bug,
  Code,
  LayoutDashboard,
  Loader2,
  TestTube,
  FileText,
  LayoutTemplate,
  Rocket,
  Wand2,
} from "lucide-react";
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarTrigger,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  SidebarInset,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import Logo from "@/components/logo";
import Dashboard from "@/components/dashboard";
import RequirementClassifier from "@/components/requirement-classifier";
import CodeGenerator from "@/components/code-generator";
import BugFixer from "@/components/bug-fixer";
import CodeSummarizer from "@/components/code-summarizer";

type View = "dashboard" | "classify" | "generate" | "fix" | "summarize";

export default function Home() {
  const [activeView, setActiveView] = React.useState<View>("dashboard");

  const renderContent = () => {
    switch (activeView) {
      case "dashboard":
        return <Dashboard />;
      case "classify":
        return <RequirementClassifier />;
      case "generate":
        return <CodeGenerator />;
      case "fix":
        return <BugFixer />;
      case "summarize":
        return <CodeSummarizer />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarHeader>
          <div className="flex items-center gap-2">
            <Logo className="w-8 h-8 text-sidebar-foreground" />
            <span className="text-lg font-semibold text-sidebar-foreground">
              SmartSDLC
            </span>
          </div>
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton
                onClick={() => setActiveView("dashboard")}
                isActive={activeView === "dashboard"}
                tooltip="Dashboard"
              >
                <LayoutDashboard />
                <span>Dashboard</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton
                onClick={() => setActiveView("classify")}
                isActive={activeView === "classify"}
                tooltip="Requirement Classification"
              >
                <FileText />
                <span>Requirement Classifier</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton
                onClick={() => setActiveView("generate")}
                isActive={activeView === "generate"}
                tooltip="AI Code Generator"
              >
                <Wand2 />
                <span>AI Code Generator</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton
                onClick={() => setActiveView("fix")}
                isActive={activeView === "fix"}
                tooltip="Bug Fixer"
              >
                <Bug />
                <span>Bug Fixer</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton
                onClick={() => setActiveView("summarize")}
                isActive={activeView === "summarize"}
                tooltip="Code Summarizer"
              >
                <BookText />
                <span>Code Summarizer</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter>
          {/* Footer content can go here */}
        </SidebarFooter>
      </Sidebar>
      <SidebarInset className="flex flex-col">
        <header className="flex items-center justify-between p-4 border-b">
          <SidebarTrigger />
          <h1 className="text-xl font-semibold capitalize">{activeView.replace('-', ' ')}</h1>
          <div className="w-7"></div>
        </header>
        <main className="flex-1 overflow-auto p-4 md:p-6 lg:p-8">
          {renderContent()}
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
